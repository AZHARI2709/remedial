<h5>Halaman Tambah Data SPP</h5>
<a href="?url=spp" class="btn btn-primary"> KEMBALI </a>
<hr>
<form method="post" action="?url=proses-tambah-spp">
    class="form-group mb-2">
      <div   <label>Tahun</label>
        <input type="number" name="tahun" maxlength="4" class="form-control"required>
    </div>
</form>